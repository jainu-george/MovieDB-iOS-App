//
//  MovieDB+CoreDataProperties.swift
//  ProjectB
//
//  Created by jithin varghese on 23/06/18.
//  Copyright © 2018 Jithin Varghese. All rights reserved.
//
//

import Foundation
import CoreData


extension MovieDB {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<MovieDB> {
        return NSFetchRequest<MovieDB>(entityName: "MovieDB")
    }

    @NSManaged public var backdropPath: String?
    @NSManaged public var movieId: Int32
    @NSManaged public var originalTitle: String?
    @NSManaged public var overview: String?
    @NSManaged public var popularity: Float
    @NSManaged public var posterPath: String?
    @NSManaged public var releaseDate: String?
    @NSManaged public var title: String?
    @NSManaged public var voteAverage: Float
    @NSManaged public var voteCount: Int32
    @NSManaged public var releaseYear: String?

}
