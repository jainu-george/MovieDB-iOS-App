//
//  MovieDB+CoreDataClass.swift
//  ProjectB
//
//  Created by jithin varghese on 23/06/18.
//  Copyright © 2018 Jithin Varghese. All rights reserved.
//
//

import Foundation
import CoreData

@objc(MovieDB)
public class MovieDB: NSManagedObject {

}
