//
//  DatabaseService.swift
//  ProjectB
//
//  Created by jithin varghese on 23/06/18.
//  Copyright © 2018 Jithin Varghese. All rights reserved.
//

import UIKit
import CoreData

class DatabaseService: NSObject {
    
    var movieList : MovieList?
    
   let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    
    
    public static var service = DatabaseService()
    
    func addMovieListToDB(){
        
       // let context = appDelegate.persistentContainer.viewContext
        
        let entity = NSEntityDescription.entity(forEntityName: "MovieDB", in: context)
        
        let newMovieDB = NSManagedObject(entity: entity!, insertInto: context)
        
         newMovieDB.setValue(movieList?.backdropPath, forKey: "backdropPath")
         newMovieDB.setValue(movieList?.movieId, forKey: "movieId")
         newMovieDB.setValue(movieList?.originalTitle, forKey: "originalTitle")
         newMovieDB.setValue(movieList?.overview, forKey: "overview")
         newMovieDB.setValue(movieList?.popularity, forKey: "popularity")
         newMovieDB.setValue(movieList?.posterPath, forKey: "posterPath")
         newMovieDB.setValue(movieList?.releaseDate, forKey: "releaseDate")
         newMovieDB.setValue(movieList?.title, forKey: "title")
         newMovieDB.setValue(movieList?.voteAverage, forKey: "voteAverage")
         newMovieDB.setValue(movieList?.voteCount, forKey: "voteCount")
        newMovieDB.setValue(movieList?.releaseYear, forKey: "releaseYear")
        
       
        
        do {
            try context.save()
            print( "saving done")
        } catch {
            print("Failed saving")
        }
        
    }
    
    func getMoviedetails() -> [MovieDB]
    {
        var moviedetails = [MovieDB]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "MovieDB")
        do{
            moviedetails = try context.fetch(fetchRequest) as! [MovieDB]
        }
        catch{
            print ("Error")
        }
        return moviedetails
        
    }

}
