//
//  Movie.swift
//  ProjectB
//
//  Created by jithin varghese on 21/06/18.
//  Copyright © 2018 Jithin Varghese. All rights reserved.
//

import UIKit

class MovieData: NSObject {

    
    var movieList : [MovieList]!
    
    
    /**
     * Instantiate the instance using the passed dictionary values to set the properties values
     */
    init(fromDictionary dictionary: [String:Any]){
        movieList = [MovieList]()
        if let resultsArray = dictionary["results"] as? [[String:Any]]{
            for dic in resultsArray{
                let value = MovieList(fromDictionary: dic)
                movieList.append(value)
            }
        }
    }
    
}

class MovieList : NSObject{
    
    var backdropPath : String!
    var movieId : Int!
    var originalTitle : String!
    var overview : String!
    var popularity : Float!
    var posterPath : String!
    var releaseDate : String!
    var title : String!
    var voteAverage : Float!
    var voteCount : Int!
    var releaseYear : String!
    
    
    /**
     * Instantiate the instance using the passed dictionary values to set the properties values
     */
    init(fromDictionary dictionary: [String:Any]){
       
        backdropPath = dictionary["backdrop_path"] as? String
        movieId = dictionary["id"] as? Int
        originalTitle = dictionary["original_title"] as? String
        overview = dictionary["overview"] as? String
        popularity = dictionary["popularity"] as? Float
        posterPath = dictionary["poster_path"] as? String
        title = dictionary["title"] as? String
        voteAverage = dictionary["vote_average"] as? Float
        voteCount = dictionary["vote_count"] as? Int
        
        if ((dictionary["release_date"] as? String)?.isEmpty)!{
            
        }else{
        
        if let getDate = (dictionary["release_date"] as? String){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "YYYY-MM-DD"
        let date = dateFormatter.date(from:getDate)
        
        dateFormatter.dateFormat = "MMM DD,YYYY"
            releaseDate = dateFormatter.string(from: (date)!)
        
        dateFormatter.dateFormat = "YYYY"
            releaseYear = dateFormatter.string(from: (date)!)
        }
        }
    }
    
}
