//
//  SavedMovieListTableViewCell.swift
//  ProjectB
//
//  Created by jithin varghese on 23/06/18.
//  Copyright © 2018 Jithin Varghese. All rights reserved.
//

import UIKit

class SavedMovieListTableViewCell: UITableViewCell {
    @IBOutlet weak var lblRating: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgMovie: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
