//
//  SearchListTableViewCell.swift
//  ProjectB
//
//  Created by jithin varghese on 22/06/18.
//  Copyright © 2018 Jithin Varghese. All rights reserved.
//

import UIKit

class SearchListTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imgMovie: UIImageView!
    
    @IBOutlet weak var lblMovieName: UILabel!
    
    @IBOutlet weak var lblVote: UILabel!
    
    @IBOutlet weak var lblReleaseDate: UILabel!
    
    
    var movieData : MovieList?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func ShowData()
    {
        if let imageUrl = movieData?.posterPath{
            do {
                let url = URL(string: "https://image.tmdb.org/t/p/w500\(imageUrl)")
                let data = try Data(contentsOf: url!)
                self.imgMovie.image = UIImage(data: data)
            }
            catch{
                print(error)
            }
            
        }
        if let name = movieData?.title{
            if (movieData?.releaseYear == nil){
                 lblMovieName.text = name
            }else{
            lblMovieName.text = name + "(" + (movieData?.releaseYear)! + ")"
            }
            
        }
        if let vote = movieData?.voteAverage{
            self.lblVote.text = "Users Vote: \(vote)/10"
        }
        if let date = movieData?.releaseDate{
            self.lblReleaseDate.text = "Released Date: \(date)"
        }
        
        
    }

}
