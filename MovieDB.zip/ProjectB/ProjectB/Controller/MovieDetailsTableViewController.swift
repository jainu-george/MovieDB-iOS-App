//
//  MovieDetailsTableViewController.swift
//  ProjectB
//
//  Created by jithin varghese on 23/06/18.
//  Copyright © 2018 Jithin Varghese. All rights reserved.
//

import UIKit

class MovieDetailsTableViewController: UITableViewController {
    
    @IBOutlet weak var lblVote: UILabel!
    @IBOutlet weak var lblReleasedDate: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    var movieDetails : MovieList?
    @IBOutlet weak var imgPoster: UIImageView!
    
    @IBOutlet weak var imgCover: UIImageView!
    @IBOutlet weak var lblOverview: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        self.title = movieDetails?.title
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Save", style: .plain, target: self, action: #selector(saveBtnTapped))
        
        imgPoster.layer.borderWidth = 4
        imgPoster.layer.borderColor = UIColor(red: 27/255, green: 0, blue: 0, alpha: 1.0) .cgColor
        
        self.ShowData()
        
        
    }
    @objc func saveBtnTapped(){

        let service = DatabaseService.service
        service.movieList = movieDetails
        service.addMovieListToDB()
        
        
        let alert = UIAlertController(title: "MovieDB", message: "Movie Saved to the List", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler:nil))
        self.present(alert, animated: true, completion: nil)
        
    }
    
    func ShowData()
    {
        if let imageUrl = movieDetails?.posterPath{
            do {
                let url = URL(string: "https://image.tmdb.org/t/p/w500\(imageUrl)")
                let data = try Data(contentsOf: url!)
                self.imgPoster.image = UIImage(data: data)
            }
            catch{
                print(error)
            }
            
        }
        
        if let coverImageUrl = movieDetails?.backdropPath{
            do {
                let url = URL(string: "https://image.tmdb.org/t/p/w500\(coverImageUrl)")
                let data = try Data(contentsOf: url!)
                self.imgCover.image = UIImage(data: data)
            }
            catch{
                print(error)
            }
            
        }
        if let name = movieDetails?.title{
            if (movieDetails?.releaseYear == nil){
                lblTitle.text = name
            }else{
                lblTitle.text = name + "(" + (movieDetails?.releaseYear)! + ")"
            }
            
        }
        if let vote = movieDetails?.voteAverage{
            self.lblVote.text = "Users Vote: \(vote)/10"
        }
        if let date = movieDetails?.releaseDate{
            self.lblReleasedDate.text = "Released Date: \(date)"
        }
        if let overView = movieDetails?.overview{
            self.lblOverview.text = overView
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 3
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0
        {
            return 253
        }else if indexPath.row == 1{
            return self.tableView.estimatedRowHeight
        }
        else if indexPath.row == 2{
            return self.tableView.estimatedRowHeight
        }else{
            return 0
        }
    }
    
}
