//
//  SearchViewController.swift
//  ProjectB
//
//  Created by jithin varghese on 19/06/18.
//  Copyright © 2018 Jithin Varghese. All rights reserved.
//

import UIKit

class SearchViewController: UIViewController {
    
    var moviesData : MovieData?
    var MoviesList : [MovieList]?
    @IBOutlet weak var searchBar: UISearchBar!
    var task : URLSessionDataTask?
    
    @IBOutlet weak var movieListTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.title = "Search Movies"
        
        /**To remove the "Back" title from thw navivation bar**/
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        DispatchQueue.main.async {
            
            self.searchBar.becomeFirstResponder()
            
            
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SearchViewController : UITableViewDelegate,UITableViewDataSource{
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if((MoviesList?.count)! > 0){
            
            return (MoviesList?.count)!
        }else{
            return 0
            
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.movieListTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! SearchListTableViewCell
        cell.movieData = MoviesList?[indexPath.row]
        cell.ShowData()
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let MovieDetailtVC = self.storyboard?.instantiateViewController(withIdentifier: "movieDetailScene") as! MovieDetailsTableViewController
        MovieDetailtVC.movieDetails = MoviesList?[indexPath.row]
        self.navigationController?.pushViewController(MovieDetailtVC, animated: true)
    }
    
    
}

extension SearchViewController : UISearchBarDelegate{
    
    func updateSearchResults(for searchController: UISearchController){
        
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if task?.state == .running{
            MoviesList?.removeAll()
            task?.cancel()
        }
        
        DispatchQueue.main.async {
            self.getMovieListBySearch(searchtext: searchBar.text!)
        }
    }
    
    public func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        print(searchBar.text!)
        // self.currentPage = 1
        // self.helpDeskList.removeAll()
        //strSearchKey = searchBar.text!
        self.searchBar.resignFirstResponder()
        if (searchBar.text?.isEmpty)!{
            let alert = UIAlertController(title: "MovieDB", message: "Please enter the text to search the movies!", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler:nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = true;
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = false;
    }
    
    
    
    public func searchBarCancelButtonClicked(_ searchBar: UISearchBar){
        
        self.searchBar.resignFirstResponder()
        
        //        self.moviesData.removeAll()
        // strSearchKey = nil
        
        //self.getHelpDeskListFromServer()
        
    }
    
    func getMovieListBySearch(searchtext :String){
        
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        let urlString = "https://api.themoviedb.org/3/search/movie?api_key=5ca48ad22a8d2de44cf71a6b083f08fa&language=en-US&query=\(searchtext)&page=1&include_adult=false"
        let qurl = URL(string: urlString.addingPercentEncoding( withAllowedCharacters: .urlQueryAllowed)!)
        let request = URLRequest(url: qurl!)
        task = URLSession.shared.dataTask(with: request, completionHandler:
            {
                (data,response,error)
                
                in
                
                if(error == nil)
                {
                    do{
                        
                        let jsonData = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:Any]
                        
                        self.moviesData = MovieData(fromDictionary: jsonData)
                        if self.moviesData?.movieList != nil{
                            self.MoviesList = self.moviesData?.movieList
                        }
                        
                        DispatchQueue.main.async {
                            
                            self.movieListTableView.dataSource = self
                            self.movieListTableView.delegate = self
                            self.movieListTableView.reloadData()
                            UIApplication.shared.isNetworkActivityIndicatorVisible = false
                        }
                        
                        
                        
                        
                    }
                    catch
                    {
                        print("JSON Format data error")
                    }
                    
                    
                }
                else
                {
                    print("Error")
                }
        }
        )
        task?.resume()
    }
    
    
}






