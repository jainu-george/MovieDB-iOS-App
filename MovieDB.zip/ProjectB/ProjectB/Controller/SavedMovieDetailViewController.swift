
//  SavedMovieDetailViewController.swift
//  MovieDBJN
//
//  Created by Nithin Prasanna Kumar on 23/06/18.
//  Copyright © 2018 Nithin Prasanna Kumar. All rights reserved.
//

import UIKit

class SavedMovieDetailViewController: UIViewController {
    
    @IBOutlet weak var movieImage: UIImageView!
    
    @IBOutlet weak var movieTitle: UILabel!
    
    @IBOutlet weak var ratingtxt: UILabel!
    
    @IBOutlet weak var releaseDatetxt: UILabel!
    
    @IBOutlet weak var descriptiontxt: UITextView!
    
    var movieDetail : MovieDB?
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //movieImage.image = movieDetail?.movieImage
        
        movieTitle.text = movieDetail?.title
        releaseDatetxt.text = movieDetail?.releaseDate
        if let imageurl = movieDetail?.posterPath{
            do {
                let url = URL(string: "https://image.tmdb.org/t/p/w500\(imageurl)")
                let data = try Data(contentsOf: url!)
                movieImage.image = UIImage(data: data)
            }
            catch{
                print(error)
            }
        }
       
        if let popularity = movieDetail?.popularity {
            ratingtxt.text = "Popularity:\(popularity)"
        }
        descriptiontxt.text = movieDetail?.overview
        
        
    }
    
    // override func didReceiveMemoryWarning() {
    //   super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
}



