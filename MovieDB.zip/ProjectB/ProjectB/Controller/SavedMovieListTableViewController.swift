//
//  SavedMovieListTableViewController.swift
//  MovieDBJN
//
//  Created by Nithin Prasanna Kumar on 23/06/18.
//  Copyright © 2018 Nithin Prasanna Kumar. All rights reserved.
//

import UIKit
import CoreData


class SavedMovieListTableViewController: UITableViewController {
   
    var movies : [MovieDB]?
   

    override func viewDidLoad() {
        super.viewDidLoad()
        let service = DatabaseService.service
        self.movies = service.getMoviedetails()
        
        self.title = "Movie List"
    
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
         DispatchQueue.main.async {
        let service = DatabaseService.service
        self.movies = service.getMoviedetails()
        if (self.movies?.count)! > 0{
//            tableView.dataSource? = self
//            tableView.delegate? = self
            self.tableView.reloadData()
        }
    }
        
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
          if (movies?.count)! > 0{
        return (movies?.count)!
        }
          else{
            return 0
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! SavedMovieListTableViewCell
        if let imageurl = movies?[indexPath.row].posterPath{
         do {
        let url = URL(string: "https://image.tmdb.org/t/p/w500\(imageurl)")
        let data = try Data(contentsOf: url!)
        cell.imgMovie.image = UIImage(data: data)
         }
         catch{
            print(error)
        }
        }
        cell.lblTitle.text = movies?[indexPath.row].title
        if let popularity = movies?[indexPath.row].popularity {
            let value = String(format: "%.3f",popularity)
            cell.lblRating.text = "Popularity:\(value)"
        }
        return cell
    }


    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
       
        performSegue(withIdentifier:"segue", sender: movies?[indexPath.row])
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender:(Any)?) {
        
        let detailVC : SavedMovieDetailViewController = segue.destination as! SavedMovieDetailViewController
        
        detailVC.movieDetail = sender as? MovieDB
        
    }
    
    
}



